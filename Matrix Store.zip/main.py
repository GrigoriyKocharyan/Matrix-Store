from customtkinter import *
from settings import *
from variables import *
from lines import *


def draw_aside_buttons(win):
    for i in range(len(aside_buttons_names)):
        if aside_buttons_names[i][0] == '/':
            aside_buttons.append(CTkLabel(
                text=aside_buttons_names[i][1::],
                master=win,
                font=("Arial", 12, 'bold'),
                text_color="#999999"
            ))
        else:
            aside_buttons.append(CTkButton(
                text=aside_buttons_names[i],
                master=win,
                height=30,
                width=150,
                fg_color="#FFFFFF",
                hover_color="#EBEBEB",
                text_color="#3B3B3B",
                anchor='w',
                font=("Microsoft Sans Serif", 13)))

    index = 0
    for aside_button in aside_buttons:
        aside_button.place(x=10, y=50 + 35 * index)
        aside_button.bind('<Enter>', on_enter)
        aside_button.bind('<Leave>', on_leave)
        index += 1


def main_button_click(event):
    upside_draw_lines("гл")


def profile_button_click(event):
    upside_draw_lines("пр")


def on_enter(event):
    win.config(cursor="hand2")


def on_leave(event):
    win.config(cursor="arrow")


def fordevs_button_click(event):
    upside_draw_lines("дл")


def draw_upside_buttons(win):
    for i in range(len(upside_buttons_names)):
        upside_buttons.append(CTkButton(
            master=win,
            height=30,
            width=10,
            fg_color="#FFFFFF",
            hover_color="#EBEBEB",
            text_color="#3B3B3B",
            anchor='w',
            font=("Microsoft Sans Serif", 13)))
    print("Successful1")

    index = 0
    for upside_button in upside_buttons:
        upside_button.place(x=10 + 80 * index, y=5)

        upside_button.bind('<Enter>', on_enter)
        upside_button.bind('<Leave>', on_leave)

        upside_button.configure(text=upside_buttons_names[index])

        if "Г" in upside_button.cget("text"):
            upside_button.bind('<Button-1>', main_button_click)
        if "П" in upside_button.cget("text"):
            upside_button.bind('<Button-1>', profile_button_click)
        if "Д" in upside_button.cget("text"):
            upside_button.bind('<Button-1>', fordevs_button_click)
        index += 1
    print("Successful2")


win = CTk(fg_color="#FFFFFF")
win.geometry(f"{W}x{H}")

draw_lines(win)
draw_aside_buttons(win)
draw_upside_buttons(win)

win.mainloop()
