from customtkinter import *
from settings import *


def draw_lines(win):
    global bg
    bg = CTkCanvas(win, width=W, height=H,
                   background="#FFFFFF")
    bg.place(x=0, y=0)

    bg.create_rectangle(170, 0, W, H, fill="#F4F4F4", outline="#F4F4F4")
    bg.create_line(170, 40, 170, H, fill="#DFDFDF", width=2)

    bg.create_rectangle(0, 0, W, 40, fill="#FFFFFF", outline="#FFFFFF")
    bg.create_line(0, 40, W, 40, fill="#DFDFDF", width=2)


def upside_draw_lines(upside_line):
    if upside_line == "гл":
        bg.create_line(10, 40, 77, 40, fill="#000000", width=2)
        bg.create_line(90, 40, 167, 40, fill="#DFDFDF", width=2)
        bg.create_line(170, 40, 310, 40, fill="#DFDFDF", width=2)
    if upside_line == "пр":
        bg.create_line(10, 40, 77, 40, fill="#DFDFDF", width=2)
        bg.create_line(90, 40, 167, 40, fill="#000000", width=2)
        bg.create_line(170, 40, 310, 40, fill="#DFDFDF", width=2)
    if upside_line == "дл":
        bg.create_line(10, 40, 77, 40, fill="#DFDFDF", width=2)
        bg.create_line(90, 40, 167, 40, fill="#DFDFDF", width=2)
        bg.create_line(170, 40, 310, 40, fill="#000000", width=2)
