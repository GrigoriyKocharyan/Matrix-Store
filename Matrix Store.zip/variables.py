import tkinter.font as font

aside_buttons = []
aside_labels = []
aside_buttons_names = [
    "/ГЛАВНОЕ",
    "• Приложения",
    "• Категории",
    "• Поиск",
    "/ДРУГОЕ",
    "• Настройки",
]

upside_buttons = []
upside_buttons_names = [
    'Главная',
    'Профиль',
    'Для разработчиков',
]

